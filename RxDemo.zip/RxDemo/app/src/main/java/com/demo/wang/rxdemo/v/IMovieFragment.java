package com.demo.wang.rxdemo.v;

/**
 * Title:IHomeFragment
 * Package:com.tomcat360.v.view_interface
 * Description:TODO
 * Author: wwh@tomcat360.com
 * Date: 16/5/16
 * Version: V1.0.0
 * 版本号修改日期修改人修改内容
 */
public interface IMovieFragment extends IBaseFragmentView {
    void getData();
    void getDataSuccess(String str);
}
